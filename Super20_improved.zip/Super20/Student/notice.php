
<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";

$result = mysqli_query($conn, "SELECT * FROM notices ORDER BY id DESC");

if (!$result) {
    die("Error fetching notices: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Notice Board - Student</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
        }

        .container {
            width: 80%;
            margin: 40px auto;
        }

        h1 {
            text-align: center;
            color: #222;
        }

        .back-btn {
            display: inline-block;
            background: #1f2937;
            color: white;
            padding: 11px 20px;
            text-decoration: none;
            border-radius: 6px;
            margin-bottom: 20px;
            float: right;
        }

        .back-btn:hover {
            background: #0c3b86;
        }

        .notice {
            background: white;
            margin: 20px 0;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        .notice h2 {
            margin-top: 0;
            color: #007bff;
        }

        .notice p {
            font-size: 16px;
        }

        .date {
            color: gray;
            font-size: 13px;
        }
    </style>
</head>

<body>

<div class="container">

    <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>

    <h1>📢 Notice Board</h1>

    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
    ?>

        <div class="notice">
            <h2><?php echo htmlspecialchars($row['title']); ?></h2>

            <p>
                <?php echo nl2br(htmlspecialchars($row['message'])); ?>
            </p>

            <div class="date">
                <?php echo isset($row['date']) ? htmlspecialchars($row['date']) : ''; ?>
            </div>
        </div>

    <?php
        }
    } else {
        echo "<p style='text-align:center;'>No notices available.</p>";
    }
    ?>

</div>

</body>
</html>