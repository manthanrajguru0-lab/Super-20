<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";
require_once "../includes/throttle.php";

$student_id = (int)$_SESSION["student_id"];

$error = "";
$success = "";
$first_login = isset($_GET["first"]);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $current_password = (string)($_POST["current_password"] ?? "");
    $new_password = (string)($_POST["new_password"] ?? "");
    $confirm_password = (string)($_POST["confirm_password"] ?? "");
    $tkey = throttle_key("chg" . $student_id);

    if ($current_password === "" || $new_password === "" || $confirm_password === "") {

        $error = "Please fill in all three fields.";

    } elseif (throttle_blocked($conn, $tkey)) {

        $error = "Too many failed attempts. Please try again in 15 minutes.";

    } elseif (strlen($new_password) < 8) {

        $error = "New password must be at least 8 characters.";

    } elseif ($new_password !== $confirm_password) {

        $error = "Passwords do not match.";

    } elseif ($new_password === $current_password) {

        $error = "New password must be different from the current one.";

    } else {

        $stmt = $conn->prepare("SELECT password, mobile FROM students WHERE id = ?");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $current_ok = false;
        if ($row) {
            $current_ok = !empty($row["password"])
                ? password_verify($current_password, $row["password"])
                : hash_equals((string)$row["mobile"], trim($current_password));
        }

        if (!$current_ok) {

            throttle_fail($conn, $tkey);
            $error = "Current password is incorrect.";

        } else {

            $hash = password_hash($new_password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("UPDATE students SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hash, $student_id);

            if ($stmt->execute()) {
                throttle_clear($conn, $tkey);
                $success = "Password changed successfully!";
                $first_login = false;
            } else {
                $error = "Unable to change password. Please try again.";
            }

            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Change Password</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #f4f6fb;
}

.container {
    width: 400px;
    max-width: 90%;
    margin: 80px auto;
}

.box {
    background: white;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 3px 15px rgba(0,0,0,0.1);
}

h1 {
    text-align: center;
    margin-bottom: 25px;
    color: #222;
}

label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
}

input {
    width: 100%;
    padding: 12px;
    margin-bottom: 18px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 15px;
}

button {
    width: 100%;
    padding: 13px;
    border: none;
    border-radius: 8px;
    background: #667eea;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #5568d9;
}

.error {
    background: #ffe5e5;
    color: red;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 18px;
    text-align: center;
}

.success {
    background: #e5ffe9;
    color: green;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 18px;
    text-align: center;
}

.back {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #667eea;
    text-decoration: none;
}

</style>

</head>

<body>

<div class="container">

    <div class="box">

        <h1>🔐 Change Password</h1>

        <?php if ($error != "") { ?>

            <div class="error">
                <?php echo htmlspecialchars($error); ?>
            </div>

        <?php } ?>

        <?php if ($success != "") { ?>

            <div class="success">
                <?php echo htmlspecialchars($success); ?>
            </div>

        <?php } ?>

        <form method="POST">
<?php echo csrf_field(); ?>

            <?php if ($first_login) { ?>
                <div class="error">Please set your own password before continuing. Your current temporary password is your registered mobile number.</div>
            <?php } ?>

            <label>Current Password</label>

            <input
                type="password"
                name="current_password"
                placeholder="Enter current password"
                autocomplete="current-password"
                required
            >

            <label>New Password</label>

            <input
                type="password"
                name="new_password"
                placeholder="Enter new password"
                minlength="8"
                required
            >

            <label>Confirm Password</label>

            <input
                type="password"
                name="confirm_password"
                placeholder="Confirm new password"
                minlength="8"
                required
            >

            <button type="submit">
                Change Password
            </button>

        </form>

        <a href="dashboard.php" class="back">
            ← Back to Dashboard
        </a>

    </div>

</div>

</body>

</html>