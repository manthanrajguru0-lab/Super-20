<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";

$student_id = $_SESSION["student_id"];

$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows != 1) {
    die("Student record not found.");
}

$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Profile</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #f4f6fb;
}

.container {
    max-width: 700px;
    margin: 50px auto;
    background: white;
    padding: 35px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,.1);
}

h1 {
    text-align: center;
    margin-bottom: 30px;
    color: #222;
}

.profile-row {
    display: flex;
    justify-content: space-between;
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.profile-row strong {
    color: #333;
}

.profile-row span {
    color: #666;
}

.back {
    display: inline-block;
    margin-top: 25px;
    padding: 10px 20px;
    background: #667eea;
    color: white;
    text-decoration: none;
    border-radius: 8px;
}

.back:hover {
    background: #5568d9;
}

</style>
</head>

<body>

<div class="container">

    <h1>👤 My Profile</h1>

    <div class="profile-row">
        <strong>Student Code</strong>
        <span><?php echo htmlspecialchars($student["student_code"]); ?></span>
    </div>

    <div class="profile-row">
        <strong>Full Name</strong>
        <span><?php echo htmlspecialchars($student["full_name"]); ?></span>
    </div>

    <div class="profile-row">
        <strong>Mobile Number</strong>
        <span><?php echo htmlspecialchars($student["mobile"]); ?></span>
    </div>

    <div class="profile-row">
        <strong>Course</strong>
        <span><?php echo htmlspecialchars($student["course"]); ?></span>
    </div>

    <div class="profile-row">
        <strong>Batch</strong>
        <span><?php echo htmlspecialchars($student["batch"]); ?></span>
    </div>

    <div class="profile-row">
        <strong>Status</strong>
        <span><?php echo htmlspecialchars($student["status"]); ?></span>
    </div>

    <a href="dashboard.php" class="back">← Back to Dashboard</a>

</div>

</body>
</html>