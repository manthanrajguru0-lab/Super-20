<?php
require_once __DIR__ . "/../includes/security.php";
require_once "../config/database.php";
require_once "../includes/throttle.php";
csrf_protect();

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $student_code = trim($_POST["student_code"] ?? "");
    $password = (string)($_POST["password"] ?? "");

    if ($student_code === "" || $password === "") {

        $error = "Please enter Student Code and Password!";

    } else {

        $tkey = throttle_key($student_code);

        if (throttle_blocked($conn, $tkey)) {

            $error = "Too many failed attempts. Please try again in 15 minutes.";

        } else {

            $stmt = $conn->prepare(
                "SELECT id, student_code, full_name, mobile, course, batch, password
                 FROM students
                 WHERE student_code = ? AND status = 'Active'"
            );
            $stmt->bind_param("s", $student_code);
            $stmt->execute();
            $student = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $ok = false;
            $first_login = false;

            if ($student) {
                if (!empty($student["password"])) {
                    // Normal case: hashed password chosen by the student
                    $ok = password_verify($password, $student["password"]);
                } else {
                    // First login only: the mobile number is the temporary password
                    $ok = hash_equals((string)$student["mobile"], trim($password));
                    $first_login = $ok;
                }
            }

            if ($ok) {

                throttle_clear($conn, $tkey);
                session_regenerate_id(true);

                $_SESSION["student_id"] = $student["id"];
                $_SESSION["student_code"] = $student["student_code"];
                $_SESSION["student_name"] = $student["full_name"];
                $_SESSION["student_mobile"] = $student["mobile"];
                $_SESSION["student_course"] = $student["course"];
                $_SESSION["student_batch"] = $student["batch"];
                $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

                // Temporary password -> force the student to choose their own
                header("Location: " . ($first_login ? "forgot_password.php?first=1" : "dashboard.php"));
                exit();

            } else {

                throttle_fail($conn, $tkey);
                usleep(300000);
                $error = "Invalid Student Code or Password!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Student Login</title>

<style>

/* ==============================
   RESET
============================== */

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

/* ==============================
   BODY
============================== */

body {
    margin: 0;
    min-height: 100vh;

    display: flex;
    justify-content: center;
    align-items: center;

    background: linear-gradient(
        135deg,
        #667eea,
        #764ba2
    );
}

/* ==============================
   LOGIN BOX
============================== */

.login-box {
    width: 380px;

    background: white;

    padding: 35px;

    border-radius: 15px;

    box-shadow:
        0 10px 30px rgba(0, 0, 0, 0.2);
}

/* ==============================
   HEADING
============================== */

h2 {
    text-align: center;

    margin-top: 0;
    margin-bottom: 8px;

    color: #333;
}

.subtitle {
    text-align: center;

    color: #777;

    margin-top: 0;
    margin-bottom: 25px;
}

/* ==============================
   ERROR
============================== */

.error {
    background: #ffe5e5;

    color: #d00000;

    padding: 10px;

    border-radius: 7px;

    margin-bottom: 18px;

    text-align: center;

    font-size: 14px;
}

/* ==============================
   LABEL
============================== */

label {
    display: block;

    margin-bottom: 7px;

    font-weight: bold;

    color: #333;
}

/* ==============================
   NORMAL INPUT
============================== */

input {
    width: 100%;

    padding: 12px;

    margin-bottom: 18px;

    border: 1px solid #ddd;

    border-radius: 8px;

    outline: none;

    font-size: 15px;
}

input:focus {
    border-color: #667eea;

    box-shadow:
        0 0 0 2px rgba(102, 126, 234, 0.1);
}

/* ==============================
   PASSWORD BOX
============================== */

.password-box {
    position: relative;

    width: 100%;
}

/* Password input */

.password-box input {
    width: 100%;

    padding: 12px 65px 12px 12px;

    margin-bottom: 18px;
}

/* ==============================
   SHOW / HIDE BUTTON
============================== */

.password-toggle {
    position: absolute;

    right: 10px;

    top: 8px;

    width: auto;

    padding: 5px 8px;

    margin: 0;

    background: transparent;

    color: #667eea;

    border: none;

    font-size: 14px;

    font-weight: bold;

    cursor: pointer;
}

.password-toggle:hover {
    background: transparent;

    color: #5568d9;
}

/* ==============================
   LOGIN BUTTON
============================== */

.login-button {
    width: 100%;

    padding: 12px;

    border: none;

    border-radius: 8px;

    background: #667eea;

    color: white;

    font-size: 16px;

    cursor: pointer;

    transition: 0.2s;
}

.login-button:hover {
    background: #5568d9;
}

/* ==============================
   SIGNUP LINK
============================== */

.signup-link {
    text-align: center;

    margin-top: 20px;

    color: #555;
}

.signup-link a {
    color: #667eea;

    text-decoration: none;

    font-weight: bold;
}

.signup-link a:hover {
    text-decoration: underline;
}

/* ==============================
   MOBILE
============================== */

@media (max-width: 480px) {

    .login-box {
        width: calc(100% - 30px);

        padding: 25px;
    }

}

</style>

</head>

<body>

<div class="login-box">

    <h2>Student Login</h2>

    <p class="subtitle">
        Login to your student account
    </p>


    <!-- ERROR MESSAGE -->

    <?php if ($error != "") { ?>

        <div class="error">
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php } ?>


    <!-- LOGIN FORM -->

    <form method="POST">
<?php echo csrf_field(); ?>


        <!-- STUDENT CODE -->

        <label for="student_code">
            Student Code
        </label>

        <input
            type="text"
            id="student_code"
            name="student_code"
            placeholder="Enter Student Code"
            autocomplete="username"
            required
        >


        <!-- PASSWORD -->

        <label for="password">
            Password
        </label>

        <div class="password-box">

            <input
                type="password"
                id="password"
                name="password"
                placeholder="Enter Password"
                autocomplete="current-password"
                required
            >

            <button
                type="button"
                class="password-toggle"
                id="passwordToggle"
                onclick="togglePassword()"
            >
                Show
            </button>

        </div>


        <!-- LOGIN BUTTON -->

        <button
            type="submit"
            class="login-button"
        >
            Login
        </button>

    </form>


    <!-- Accounts are created by the academy office -->

</div>


<script>

/*
========================================
SHOW / HIDE PASSWORD
========================================
*/

function togglePassword() {

    const password =
        document.getElementById("password");

    const toggle =
        document.getElementById("passwordToggle");


    if (password.type === "password") {

        // Show password
        password.type = "text";

        toggle.textContent = "Hide";

    } else {

        // Hide password
        password.type = "password";

        toggle.textContent = "Show";
    }
}

</script>

</body>

</html>