<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

$student_name = $_SESSION["student_name"];
$student_mobile = $_SESSION["student_mobile"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f6fb;
        }

        .sidebar {
            position: fixed;
            width: 240px;
            height: 100vh;
            background:  #0f172a;
            color: white;
            padding: 25px 15px;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 13px 15px;
            margin: 6px 0;
            border-radius: 8px;
        }

        .sidebar a:hover {
            background: #374151;
        }

        .logout {
            margin-top: 30px !important;
            background: #dc2626;
        }

        .main {
            margin-left: 240px;
            padding: 30px;
        }

        .topbar {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 25px;
        }

        .topbar h1 {
            color: #222;
            margin-bottom: 7px;
        }

        .topbar p {
            color: #777;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
        }

        .card h3 {
            margin-bottom: 10px;
            color: #333;
        }

        .card p {
            color: #777;
            margin-bottom: 15px;
        }

        .card a {
            display: inline-block;
            padding: 9px 18px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 7px;
        }

        .profile {
            margin-top: 25px;
            background: white;
            padding: 25px;
            border-radius: 12px;
        }

        .profile h2 {
            margin-bottom: 15px;
        }

        .profile p {
            margin: 10px 0;
            color: #555;
        }

        @media (max-width: 900px) {
            .cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main {
                margin-left: 0;
            }

            .cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<div class="sidebar">

    <h2>SUPER20</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="profile.php">👤 My Profile</a>
    <a href="attendence.php">📅 Attendance</a>
    <a href="marks.php">📝 Marks</a>
    <a href="fees.php">💰 Fees</a>
    <a href="notice.php">📢 Notices</a>
    <a href="timetable.php">🕐 Timetable</a>
    <a href="forgot_password.php">🔐 Change Password</a>

    <a href="logout.php" class="logout">🚪 Logout</a>

</div>

<div class="main">

    <div class="topbar">
        <h1>Welcome, <?php echo htmlspecialchars($student_name); ?> 👋</h1>
        <p>Welcome to your Student Dashboard</p>
    </div>

    <div class="cards">

        <div class="card">
            <h3>👤 My Profile</h3>
            <p>View your student details</p>
            <a href="profile.php">View</a>
        </div>

        <div class="card">
            <h3>📅 Attendance</h3>
            <p>Check your attendance</p>
            <a href="attendence.php">View</a>
        </div>

        <div class="card">
            <h3>📝 Marks</h3>
            <p>Check your exam marks</p>
            <a href="marks.php">View</a>
        </div>

        <div class="card">
            <h3>💰 Fees</h3>
            <p>View and pay your fees</p>
            <a href="fees.php">Pay Now</a>
        </div>

        <div class="card">
            <h3>📢 Notices</h3>
            <p>View classes notices</p>
            <a href="notice.php">View</a>
        </div>

        <div class="card">
            <h3>🕐 Timetable</h3>
            <p>View your class timetable</p>
            <a href="timetable.php">View</a>
        </div>

    </div>

    <div class="profile">

        <h2>Student Information</h2>

        <p>
            <strong>Name:</strong>
            <?php echo htmlspecialchars($student_name); ?>
        </p>

        <p>
            <strong>Mobile:</strong>
            <?php echo htmlspecialchars($student_mobile); ?>
        </p>

    </div>

</div>

</body>
</html>