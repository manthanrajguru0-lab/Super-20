<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";

$student_id = $_SESSION["student_id"];

/*
    Attendance table se student ka data nikalega.
    Agar abhi attendance table nahi banaya hai,
    pehle neeche diya SQL database mein run karo.
*/

$stmt = $conn->prepare("
    SELECT 
        COUNT(*) AS total_classes,
        SUM(status = 'Present') AS present_classes,
        SUM(status = 'Absent') AS absent_classes
    FROM attendance
    WHERE student_id = ?
");

$stmt->bind_param("i", $student_id);
$stmt->execute();

$result = $stmt->get_result();
$attendance = $result->fetch_assoc();

$total = $attendance["total_classes"] ?? 0;
$present = $attendance["present_classes"] ?? 0;
$absent = $attendance["absent_classes"] ?? 0;

$percentage = ($total > 0) ? round(($present / $total) * 100, 2) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Attendance</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #f4f6fb;
}

.container {
    max-width: 900px;
    margin: 50px auto;
    padding: 20px;
}

h1 {
    text-align: center;
    margin-bottom: 30px;
    color: #222;
}

.cards {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
}

.card {
    background: white;
    padding: 25px 15px;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
}

.card h2 {
    font-size: 30px;
    margin: 10px 0;
    color: #667eea;
}

.card p {
    color: #777;
}

.back {
    display: block;
    width: 200px;
    text-align: center;
    margin: 35px auto;
    padding: 11px;
    background: #667eea;
    color: white;
    text-decoration: none;
    border-radius: 8px;
}

@media (max-width: 700px) {
    .cards {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 450px) {
    .cards {
        grid-template-columns: 1fr;
    }
}

</style>
</head>

<body>

<div class="container">

    <h1>📅 My Attendance</h1>

    <div class="cards">

        <div class="card">
            <p>Total Classes</p>
            <h2><?php echo $total; ?></h2>
        </div>

        <div class="card">
            <p>Present</p>
            <h2><?php echo $present; ?></h2>
        </div>

        <div class="card">
            <p>Absent</p>
            <h2><?php echo $absent; ?></h2>
        </div>

        <div class="card">
            <p>Attendance</p>
            <h2><?php echo $percentage; ?>%</h2>
        </div>

    </div>

    <a href="dashboard.php" class="back">← Back to Dashboard</a>

</div>

</body>
</html>