<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";
require_once "../includes/fees_helper.php";

$student_id = (int)$_SESSION["student_id"];

$amount = isset($_POST["amount"]) ? round((float)$_POST["amount"], 2) : 0;
$payment_mode = isset($_POST["payment_mode"]) ? trim($_POST["payment_mode"]) : "";
$reference_no = isset($_POST["reference_no"]) ? trim($_POST["reference_no"]) : "";

$summary = student_fee_summary($conn, $student_id);

if (
    $_SERVER["REQUEST_METHOD"] !== "POST" ||
    !in_array($payment_mode, PAYMENT_MODES, true) ||
    $summary["payable"] <= 0 ||
    $amount < fee_min_amount($summary["payable"]) ||
    $amount > $summary["payable"]
) {
    header("Location: fees.php");
    exit();
}

$error = "";
$success = false;
$receipt_no = "";
$payment_date = date("Y-m-d");

if (!preg_match('/^[A-Za-z0-9\-\/]{4,40}$/', $reference_no)) {

    $error = "Please enter a valid transaction / reference number (4-40 letters, digits, - or /).";

} else {

    /* The same reference number cannot be submitted twice */
    $dup = $conn->prepare("SELECT id FROM fees WHERE reference_no = ? LIMIT 1");
    $dup->bind_param("s", $reference_no);
    $dup->execute();
    $already = $dup->get_result()->num_rows > 0;
    $dup->close();

    if ($already) {

        $error = "This reference number has already been submitted.";

    } else {

        $receipt_no = "REC" . date("YmdHis") . random_int(100, 999);
        $remarks = "Student payment - awaiting verification";

        /* Saved as Pending: it counts as paid only after an admin approves it */
        $insert = $conn->prepare("
            INSERT INTO fees
            (student_id, amount, payment_date, payment_mode, receipt_no, remarks, status, reference_no)
            VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?)
        ");

        $insert->bind_param(
            "idsssss",
            $student_id,
            $amount,
            $payment_date,
            $payment_mode,
            $receipt_no,
            $remarks,
            $reference_no
        );

        $success = $insert->execute();

        if (!$success) {
            error_log("Payment insert failed: " . $insert->error);
            $error = "Payment could not be recorded. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Payment Submitted</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #f4f6fb;
}

.container {
    max-width: 500px;
    margin: 70px auto;
    padding: 20px;
}

.success-box {
    background: white;
    padding: 35px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
    text-align: center;
}

.icon {
    font-size: 60px;
    margin-bottom: 10px;
}

h1 {
    color: green;
}

.amount {
    font-size: 25px;
    font-weight: bold;
    color: #667eea;
    margin: 20px 0;
}

.receipt {
    background: #f4f6fb;
    padding: 15px;
    border-radius: 8px;
    margin: 20px 0;
}

.receipt p {
    margin: 8px 0;
}

.btn {
    display: block;
    width: 100%;
    padding: 13px;
    margin-top: 15px;
    border-radius: 8px;
    background: #667eea;
    color: white;
    text-decoration: none;
}

.btn:hover {
    background: #5568d9;
}

</style>

</head>

<body>

<div class="container">

<div class="success-box">

<?php if ($success) { ?>

    <div class="icon">✅</div>

    <h1>Payment Submitted!</h1>

    <p>Your payment details were recorded and are awaiting verification by the academy. It will count towards your fees once approved.</p>

    <div class="amount">
        ₹<?php echo number_format($amount, 2); ?>
    </div>

    <div class="receipt">

        <p>
            <strong>Receipt No:</strong>
            <?php echo htmlspecialchars($receipt_no); ?>
        </p>

        <p>
            <strong>Payment Mode:</strong>
            <?php echo htmlspecialchars($payment_mode); ?>
        </p>

        <p>
            <strong>Date:</strong>
            <?php echo htmlspecialchars($payment_date); ?>
        </p>

    </div>

    <a href="fees.php" class="btn">
        View Fees & Payment History
    </a>

<?php } else { ?>

    <div class="icon">❌</div>

    <h1 style="color:red;">Payment Failed</h1>

    <p><?php echo htmlspecialchars($error ?: "Payment could not be recorded."); ?></p>

    <a href="fees.php" class="btn">
        Try Again
    </a>

<?php } ?>

</div>

</div>

</body>
</html>