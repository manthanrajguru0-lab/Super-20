<?php
require_once __DIR__ . "/../includes/security.php";

session_unset();
session_destroy();

header("Location: /super20/Student/login.php");
exit();
?>