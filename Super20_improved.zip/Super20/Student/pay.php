<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";
require_once "../includes/fees_helper.php";

$amount = isset($_POST["amount"]) ? round((float)$_POST["amount"], 2) : 0;
$payment_mode = isset($_POST["payment_mode"]) ? trim($_POST["payment_mode"]) : "";

/* Validate against the real balance on the server, not the browser's values */
$summary = student_fee_summary($conn, (int)$_SESSION["student_id"]);

if (
    $_SERVER["REQUEST_METHOD"] !== "POST" ||
    !in_array($payment_mode, PAYMENT_MODES, true) ||
    $summary["payable"] <= 0 ||
    $amount < fee_min_amount($summary["payable"]) ||
    $amount > $summary["payable"]
) {
    header("Location: fees.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Make Payment</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #f4f6fb;
}

.container {
    max-width: 500px;
    margin: 50px auto;
    padding: 20px;
}

.payment-box {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
    text-align: center;
}

h1 {
    margin-bottom: 10px;
}

.amount {
    font-size: 24px;
    color: #667eea;
    font-weight: bold;
    margin: 15px 0;
}

.qr {
    width: 250px;
    height: 250px;
    margin: 20px auto;
    display: block;
}

.info {
    color: #666;
    margin-bottom: 20px;
}

button {
    width: 100%;
    padding: 13px;
    border: none;
    border-radius: 8px;
    background: #667eea;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #5568d9;
}

.back {
    display: block;
    margin-top: 15px;
    color: #667eea;
    text-decoration: none;
}

</style>

</head>

<body>

<div class="container">

    <div class="payment-box">

        <h1>💳 Make Payment</h1>

        <p>Payment Mode</p>

        <strong>
            <?php echo htmlspecialchars($payment_mode); ?>
        </strong>

        <div class="amount">
            ₹<?php echo number_format($amount, 2); ?>
        </div>

        <?php if ($payment_mode == "UPI") { ?>

            <p class="info">
                Scan the QR Code using your UPI app
            </p>

            <img src="qr.jpg" class="qr" alt="Payment QR Code">

            <form method="POST" action="payment_success.php">
<?php echo csrf_field(); ?>

                <input type="hidden"
                       name="amount"
                       value="<?php echo $amount; ?>">

                <input type="hidden"
                       name="payment_mode"
                       value="<?php echo htmlspecialchars($payment_mode); ?>">

                <label style="display:block;margin:15px 0 6px;text-align:left;">Transaction ID / Reference No.</label>
                <input type="text"
                       name="reference_no"
                       pattern="[A-Za-z0-9\-/]{4,40}"
                       maxlength="40"
                       placeholder="e.g. UPI transaction ID"
                       style="width:100%;padding:11px;border:1px solid #ccc;border-radius:8px;"
                       required>

                <button type="submit">
                    I Have Paid
                </button>

            </form>

        <?php } else { ?>

            <p class="info">
                Please complete your payment through
                <?php echo htmlspecialchars($payment_mode); ?>.
            </p>

            <form method="POST" action="payment_success.php">
<?php echo csrf_field(); ?>

                <input type="hidden"
                       name="amount"
                       value="<?php echo $amount; ?>">

                <input type="hidden"
                       name="payment_mode"
                       value="<?php echo htmlspecialchars($payment_mode); ?>">

                <label style="display:block;margin:15px 0 6px;text-align:left;">Transaction ID / Reference No.</label>
                <input type="text"
                       name="reference_no"
                       pattern="[A-Za-z0-9\-/]{4,40}"
                       maxlength="40"
                       placeholder="e.g. UPI transaction ID"
                       style="width:100%;padding:11px;border:1px solid #ccc;border-radius:8px;"
                       required>

                <button type="submit">
                    Confirm Payment
                </button>

            </form>

        <?php } ?>

        <a href="fees.php" class="back">
            ← Back to Fees
        </a>

    </div>

</div>

</body>
</html>