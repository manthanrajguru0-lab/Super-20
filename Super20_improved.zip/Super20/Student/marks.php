<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";

$student_id = $_SESSION["student_id"];

$stmt = $conn->prepare("
    SELECT test_id, marks_obtained, created_at
    FROM marks
    WHERE student_id = ?
    ORDER BY id DESC
");

$stmt->bind_param("i", $student_id);
$stmt->execute();

$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Marks</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #f4f6fb;
}

.container {
    max-width: 900px;
    margin: 50px auto;
    padding: 20px;
}

h1 {
    text-align: center;
    margin-bottom: 30px;
    color: #222;
}

.table-box {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #667eea;
    color: white;
    padding: 13px;
    text-align: left;
}

td {
    padding: 13px;
    border-bottom: 1px solid #eee;
}

.no-data {
    text-align: center;
    padding: 30px;
    color: #777;
}

.back {
    display: block;
    width: 200px;
    text-align: center;
    margin: 30px auto;
    padding: 11px;
    background: #667eea;
    color: white;
    text-decoration: none;
    border-radius: 8px;
}

</style>

</head>

<body>

<div class="container">

    <h1>📝 My Marks</h1>

    <div class="table-box">

        <?php if ($result->num_rows > 0) { ?>

        <table>

            <tr>
                <th>Test ID</th>
                <th>Marks Obtained</th>
                <th>Date</th>
            </tr>

            <?php while ($row = $result->fetch_assoc()) { ?>

            <tr>

                <td>
                    <?php echo htmlspecialchars($row["test_id"]); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($row["marks_obtained"]); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($row["created_at"]); ?>
                </td>

            </tr>

            <?php } ?>

        </table>

        <?php } else { ?>

            <div class="no-data">
                No marks available yet.
            </div>

        <?php } ?>

    </div>

    <a href="dashboard.php" class="back">← Back to Dashboard</a>

</div>

</body>
</html>