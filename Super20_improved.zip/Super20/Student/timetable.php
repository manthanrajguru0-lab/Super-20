
<?php
require_once __DIR__ . "/../includes/security.php";
csrf_protect();

// Student Login Check
if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";

$timetable = [];

$tt_stmt = $conn->prepare("
    SELECT
        timetable.id,
        timetable.day_of_week,
        timetable.subject,
        timetable.start_time,
        timetable.end_time,
        timetable.room_no,
        batches.batch_name,
        batches.course
    FROM timetable
    INNER JOIN batches
        ON timetable.batch_id = batches.id
    WHERE batches.status = 'Active'
      AND batches.batch_name = ?
    ORDER BY
        FIELD(
            timetable.day_of_week,
            'Monday',
            'Tuesday',
            'Wednesday',
            'Thursday',
            'Friday',
            'Saturday',
            'Sunday'
        ),
        timetable.start_time
");

$my_batch = (string)($_SESSION["student_batch"] ?? "");
$result = false;
if ($tt_stmt) {
    $tt_stmt->bind_param("s", $my_batch);
    $tt_stmt->execute();
    $result = $tt_stmt->get_result();
}

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $timetable[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Timetable | Super20 Academy</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        .page-container {
            width: 95%;
            max-width: 1200px;
            margin: 30px auto;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 25px;
        }

        .page-header h1 {
            margin: 0;
        }

        .back-btn {
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 8px;
            background: #1f2937;
            color: white;
            display: inline-block;
            transition: 0.3s;
        }

        .back-btn:hover {
            background: #374151;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 13px;
            border-bottom: 1px solid #eee;
            text-align: left;
            white-space: nowrap;
        }

        th {
            background: #f5f5f5;
            font-weight: 700;
        }

        .day-badge {
            font-weight: 700;
        }

        .empty {
            text-align: center;
            padding: 30px;
            color: #777;
        }
    </style>
</head>

<body>

<div class="page-container">

    <div class="page-header">

        <div>
            <h1>My Timetable</h1>
            <p>View your academy class schedule</p>
        </div>

        <!-- Student Dashboard Button -->
        <a href="dashboard.php" class="back-btn">
            ← Back to Dashboard
        </a>

    </div>

    <div class="card">

        <?php if (!empty($timetable)): ?>

            <div class="table-wrapper">

                <table>
                    <thead>
                        <tr>
                            <th>Day</th>
                            <th>Batch</th>
                            <th>Course</th>
                            <th>Subject</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Room</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($timetable as $row): ?>

                        <tr>
                            <td class="day-badge">
                                <?php echo htmlspecialchars($row["day_of_week"]); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row["batch_name"]); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row["course"]); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row["subject"]); ?>
                            </td>

                            <td>
                                <?php echo date("h:i A", strtotime($row["start_time"])); ?>
                            </td>

                            <td>
                                <?php echo date("h:i A", strtotime($row["end_time"])); ?>
                            </td>

                            <td>
                                <?php
                                echo !empty($row["room_no"])
                                    ? htmlspecialchars($row["room_no"])
                                    : "-";
                                ?>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                    </tbody>
                </table>

            </div>

        <?php else: ?>

            <div class="empty">
                No timetable available.
            </div>

        <?php endif; ?>

    </div>

</div>

</body>
</html>
