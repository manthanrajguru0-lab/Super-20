<?php
require_once __DIR__ . "/../includes/security.php";

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit();
}

require_once "../config/database.php";
require_once "../includes/fees_helper.php";

$student_id = (int)$_SESSION["student_id"];

$error = "";
$success = "";

/* Totals come from the database; only admin-approved payments count as paid */
$summary = student_fee_summary($conn, $student_id);

$total_fees       = $summary["total"];
$paid_amount      = $summary["paid"];
$pending_amount   = $summary["pending"];
$remaining_amount = $summary["remaining"];
$payable_amount   = $summary["payable"];

/* Payment history */
$history_stmt = $conn->prepare("
    SELECT amount, payment_date, payment_mode, receipt_no, status
    FROM fees
    WHERE student_id = ?
    ORDER BY id DESC
");

$history_stmt->bind_param("i", $student_id);
$history_stmt->execute();

$history = $history_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Fees Payment</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #f4f6fb;
}

.container {
    max-width: 1000px;
    margin: 40px auto;
    padding: 20px;
}

h1 {
    text-align: center;
    margin-bottom: 30px;
}

.summary {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}

.card {
    background: white;
    padding: 25px;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
}

.card h2 {
    color: #667eea;
    margin: 10px 0;
}

.card p {
    color: #777;
}

.payment-box {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
    margin-bottom: 25px;
}

.payment-box h2 {
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 7px;
    font-weight: bold;
}

input,
select {
    width: 100%;
    padding: 12px;
    margin-bottom: 18px;
    border: 1px solid #ddd;
    border-radius: 8px;
}

button {
    width: 100%;
    padding: 13px;
    border: none;
    border-radius: 8px;
    background: #667eea;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #5568d9;
}

.error {
    background: #ffe5e5;
    color: red;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
}

.success {
    background: #e5ffe9;
    color: green;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
}

.status {
    text-align: center;
    background: #e8f5e9;
    color: green;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 25px;
    font-weight: bold;
}

.table-box {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #667eea;
    color: white;
    padding: 12px;
    text-align: left;
}

td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

.back {
    display: block;
    width: 200px;
    text-align: center;
    margin: 30px auto;
    padding: 11px;
    background: #667eea;
    color: white;
    text-decoration: none;
    border-radius: 8px;
}

@media (max-width: 700px) {

    .summary {
        grid-template-columns: 1fr;
    }

}

</style>

</head>

<body>

<div class="container">

    <h1>💰 Fees Payment</h1>

    <?php if ($error != "") { ?>

        <div class="error">
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php } ?>

    <?php if ($success != "") { ?>

        <div class="success">
            <?php echo htmlspecialchars($success); ?>
        </div>

    <?php } ?>

    <?php if ($remaining_amount == 0) { ?>

        <div class="status">
            ✅ Fees Fully Paid
        </div>

    <?php } ?>

    <div class="summary">

        <div class="card">
            <p>Total Fees</p>
            <h2>₹<?php echo number_format($total_fees, 2); ?></h2>
        </div>

        <div class="card">
            <p>Paid Amount</p>
            <h2>₹<?php echo number_format($paid_amount, 2); ?></h2>
        </div>

        <div class="card">
            <p>Remaining</p>
            <h2>₹<?php echo number_format($remaining_amount, 2); ?></h2>
        </div>

    </div>


    <?php if ($pending_amount > 0) { ?>
    <div class="payment-box">
        <p>⏳ ₹<?php echo number_format($pending_amount, 2); ?> is awaiting verification by the academy and is not yet counted as paid.</p>
    </div>
    <?php } ?>

    <?php if ($payable_amount > 0) { ?>

    <div class="payment-box">

        <h2>💳 Pay Fees</h2>

        <form method="POST" action="pay.php">
<?php echo csrf_field(); ?>

            <label>Installment Amount</label>

            <input
                type="number"
                name="amount"
                min="<?php echo (int)ceil(fee_min_amount($payable_amount)); ?>"
                max="<?php echo floor($payable_amount); ?>"
                step="1"
                placeholder="Minimum ₹<?php echo number_format(fee_min_amount($payable_amount)); ?>"
                required
            >

            <label>Payment Mode</label>

            <select name="payment_mode" required>

                <option value="">Select Payment Mode</option>
                <option value="UPI">UPI</option>
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>

            </select>

            <button type="submit">
                Pay Now
            </button>

        </form>

    </div>

    <?php } ?>


    <div class="table-box">

        <h2>📜 Payment History</h2>

        <br>

        <?php if ($history->num_rows > 0) { ?>

        <table>

            <tr>
                <th>Amount</th>
                <th>Date</th>
                <th>Payment Mode</th>
                <th>Receipt No.</th>
                <th>Status</th>
            </tr>

            <?php while ($payment = $history->fetch_assoc()) { ?>

            <tr>

                <td>
                    ₹<?php echo number_format($payment["amount"], 2); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($payment["payment_date"]); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($payment["payment_mode"]); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($payment["receipt_no"]); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($payment["status"]); ?>
                </td>

            </tr>

            <?php } ?>

        </table>

        <?php } else { ?>

            <p style="text-align:center;color:#777;">
                No payment history available.
            </p>

        <?php } ?>

    </div>


    <a href="dashboard.php" class="back">
        ← Back to Dashboard
    </a>

</div>

</body>
</html>