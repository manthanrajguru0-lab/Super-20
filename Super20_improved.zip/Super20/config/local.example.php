<?php
// Copy to config/local.php and fill in your real values.
return [
    "host" => "localhost",
    "user" => "super20_user",
    "pass" => "CHANGE_ME_STRONG_PASSWORD",
    "name" => "super20_db",
];
