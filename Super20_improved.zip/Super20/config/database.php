<?php
/*
 * Database connection.
 * Settings come from environment variables, falling back to config/local.php
 * (copy config/local.example.php to config/local.php and edit it).
 * Never run the app as MySQL "root" - create a dedicated user (see README).
 */

$cfg = [
    "host" => getenv("DB_HOST") ?: "localhost",
    "user" => getenv("DB_USER") ?: "super20_user",
    "pass" => getenv("DB_PASS") !== false ? getenv("DB_PASS") : "",
    "name" => getenv("DB_NAME") ?: "super20_db",
];

if (is_file(__DIR__ . "/local.php")) {
    $cfg = array_merge($cfg, require __DIR__ . "/local.php");
}

mysqli_report(MYSQLI_REPORT_OFF);

$conn = @new mysqli($cfg["host"], $cfg["user"], $cfg["pass"], $cfg["name"]);

if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    http_response_code(500);

    // On your own computer (localhost) show the real reason to make setup easy.
    // On a live server visitors only ever see the generic message.
    $local = in_array($_SERVER["REMOTE_ADDR"] ?? "", ["127.0.0.1", "::1"], true);

    if ($local) {
        die(
            "<h3>Database connection failed</h3>"
            . "<p><b>MySQL says:</b> " . htmlspecialchars($conn->connect_error) . "</p>"
            . "<p><b>Settings used:</b> user = <code>" . htmlspecialchars($cfg["user"])
            . "</code>, database = <code>" . htmlspecialchars($cfg["name"])
            . "</code>, host = <code>" . htmlspecialchars($cfg["host"]) . "</code></p>"
            . "<p>Fix: copy <code>config/local.example.php</code> to <code>config/local.php</code> "
            . "and enter your MySQL user/password (XAMPP default: user <code>root</code>, empty password), "
            . "make sure MySQL is started, and that database <code>" . htmlspecialchars($cfg["name"])
            . "</code> exists (import <code>setup/schema.sql</code>).</p>"
        );
    }

    die("Service temporarily unavailable. Please try again later.");
}

$conn->set_charset("utf8mb4");
unset($cfg);
